# full-screen-slider
 Full Page Image Slider and Responsive Navigation Bar With HTML, CSS & JS

# Video
 https://youtu.be/6nfykVzLLAE

 !["Full Page Image Slider and Responsive Navigation Bar With HTML, CSS & JS"](https://raw.githubusercontent.com/trananhtuat/full-screen-slider/main/Screenshot_1.png "Full Page Image Slider and Responsive Navigation Bar With HTML, CSS & JS")
